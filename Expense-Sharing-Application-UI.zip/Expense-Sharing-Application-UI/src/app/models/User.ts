export class User {
    userId!: number;
    email?: string;
    password?: string;
    role?: string; // "Admin" or "Normal"
    balance?: number;
    
}