export interface ExpenseDto {
    email: string;
    groupName: string;
    description?: string;
    amount: number;
    date: Date;
  }
  