export interface UserWithBalance {
    userId: number;
    email: string;
    balance: number;
  }