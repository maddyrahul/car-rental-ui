
export class GroupMember {
    groupMemberId!: number;
    groupId!: number;
    
    userId!: number;
    
    isSettled!: boolean;
}